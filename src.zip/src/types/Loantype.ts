interface LoanType {
  _id: string;
  loanTypeName: string;
  description: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export default LoanType;
